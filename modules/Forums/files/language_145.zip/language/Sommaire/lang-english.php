<?php
/*======================================================================= 
  PHP-Nuke Titanium | Nuke-Evolution Xtreme : PHP-Nuke Web Portal System
 =======================================================================*/


define_once("_SOMNEWPM","New Private Messages !!");
define_once("_SOMSELECTALINK","Select...");
define_once("_SOMNEWCONTENT","New content !");
define_once("_SOMRESTRICTED","Access restricted to our members");
define_once("_SOMMAIREADMINVIEWALLMODULES","<strong>Modules visible</strong><br />but unselected");

?>