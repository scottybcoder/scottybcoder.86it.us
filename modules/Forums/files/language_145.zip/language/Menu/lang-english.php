<?php
/*=======================================================================
 PHP-Nuke Titanium : Enhanced and Advanced
 =======================================================================*/

define_once("_MENU_NEWPM","New Private Messages !!");
define_once("_MENU_SELECTALINK","Select...");
define_once("_MENU_NEWCONTENT","New content !");
define_once("_MENU_RESTRICTED","Access restricted to our members");
define_once("_MENU_ADMINVIEWALLMODULES","<strong>Modules visible</strong><br />but unselected");

?>